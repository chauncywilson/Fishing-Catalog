/*
Chauncy Wilson, Object-oriented Programming 1
Final Project, Fishing Catalog
 */

//Add what best reel and line combo based on what is in the wishlist
//the switch does not allow the method to go to printWishList

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class NavigationMenu {
    /**
     * @author Chauncy Wilson
     *  * @version 1.1.0
     *  * later versions may contain fishing reels, rods, and line.
     *
     * All methods must return void.
     * @param args Creates the object to navigate through the different methods.
     * @throws FileNotFoundException needed to complete the compiling of the program.
     */
    public static void main(String[] args) throws FileNotFoundException {

        NavigationMenu menu = new NavigationMenu();
        menu.tackleVariants();
    }

    int pantherMartin = 0;
    int jakes = 0;
    int kastmaster = 0;
    int superDuper = 0;
    int sGrubSet = 0;
    int lGrubSet = 0;
    int nedStick = 0;
    int finesseStick = 0;
    int colorPowerbait = 0;
    int scentedPowerbait = 0;
    int earthworm = 0;
    int mealWorm = 0;
    int sSwimBait = 0;
    int lSwimBait = 0;
    int shallowCrankBait = 0;
    int deepCrankBait = 0;

    /**
     * No-Arg constructor
     */
    NavigationMenu() {
    }


    /**
     * The main menu to navigate through the different methods.
     * @throws FileNotFoundException needed to complete the compiling of the program.
     */
    public void tackleVariants() throws FileNotFoundException {
        File wishlist = new File("wishlist.txt");
        Scanner input = new Scanner(System.in);

            int select;
            System.out.println("1) Spinners\n2) Jigs\n3) Finesse Sticks\n4) Power Bait \n5) live Bait\n6)" +
                    " Swim Bait\n7) Crank Bait \n8) Exit");
            select = input.nextInt();
            if (select == 8){
                printWishlist(wishlist);
            }
            switch (select) {
                case 1:
                    spinners();
                    break;
                case 2:
                    jigs();
                    break;
                case 3:
                    finesseSticks();
                    break;
                case 4:
                    powerBait();
                    break;
                case 5:
                    liveBait();
                    break;
                case 6:
                    swimBait();
                    break;
                case 7:
                    crankBait();
                    break;
            }
        }

    /**
     * Manipulates the data fields (pantherMartin, jakes, kastmaster, and superDuper) by increment according to
     * the users desire.
     * @throws FileNotFoundException needed to complete the compiling of the program.
     */
    public void spinners() throws FileNotFoundException {
        Scanner input = new Scanner(System.in);

            System.out.println("Spinners are used by steadily reeling in your lure." +
                    " It is important to purchase a swivel. They tend to work best in smaller bodies of water.");

            System.out.println("\nPanther Martins help with precise casting, and work best in small river-like" +
                    "\nconditions. Jakes, Kastmasters, and Super Dupers are heavier and therefore can be cast" +
                    "\nfarther. They are best used in ponds.");

            System.out.println("1) Panther Martin: $5.00\n2) Jakes Spin-A-Lure: $4.00\n3) Kastmaster: $5.00\n4)" +
                    " Super Duper: $5.00\n5) Go Back");

            int select = input.nextInt();


            //Problem with writing into the file
        switch (select) {
            case 1 :
                pantherMartin++;
                break;

            case 2 :
                jakes++;
                break;

            case 3 :
                kastmaster++;
                break;

            case 4 :
                superDuper++;
                break;

            case 5 : tackleVariants();
        }
            spinners();
        }

    /**
     * Manipulates the data fields (sGrubSet and lGrubSet) by increment according to the users desires
     * @throws FileNotFoundException needed to complete the compiling of the program.
     */
    public void jigs() throws FileNotFoundException {
        Scanner input = new Scanner(System.in);


            System.out.println("Jigs are used to \"Bounce\" the lure from the bottom. This is done by gently" +
                    "\nlifting your rod after the lure hits the bottom then reeling in the line until it become" +
                    "\ntight. Jigs are ideal for catching bass.");

            System.out.println("You will need a ball head jig and grub soft plastics. A packet of 10 ball head" +
                    "\njigs costs about $3.00, a packet of grub soft plastics can be anywhere between $5.00 - $25.00");

            System.out.println("1) Small Jig head/grub: $8.00 - $28.00\n2) Large Jig head/grub: $8.00" +
                    " - $28.00\n3) Go Back");
            int select = input.nextInt();

        switch (select) {
            case 1 :
                sGrubSet++;
                break;

            case 2 :
                lGrubSet++;
                break;

            case 3 :
                tackleVariants();
        }
            jigs();
    }

    /**
     * Manipulates the data fields (nedStick and finesseStick) by increment according to the users desires.
     * @throws FileNotFoundException needed to complete the compiling of the program.
     */
    public void finesseSticks() throws FileNotFoundException{
        Scanner input = new Scanner(System.in);

        System.out.println("Finesse Sticks come with many different ways to rig and fish. Common ways to do so" +
                "\nare the ned rig, wacky rig, or the texas rig. You will need some ned hooks (also known as" +
                "\nshroom heads) for the ned rig, or offset or circle hooks for the other two.");

        System.out.println("1) Ned Rig Set - $9.00\n2) Finesse Stick Set - $6.00\n3) Go Back");
        int select = input.nextInt();
        switch (select) {
            case 1 :
                nedStick++;
                break;

            case 2 :
                finesseStick++;
                break;

            case 3 :
                tackleVariants();
        }
        finesseSticks();
    }

    /**
     * Manipulates the data fields (colorPowerbait and scentedPowerbait) by increment according to the users desire.
     * @throws FileNotFoundException needed to complete the compiling of the program.
     */
    public void powerBait() throws FileNotFoundException {
        Scanner input = new Scanner(System.in);

        System.out.println("Power bait is a very patient form of fishing. You scoop out a blob of power bait," +
                "\nabout the size of a jaw breaker. You will need to purchase some small split shot weights.");
        System.out.println("1) Colored Powerbait - $5.00\n2) Scented Powerbait - $5.00\n3) Go Back");

        int select = input.nextInt();
        switch (select) {
            case 1 :
                colorPowerbait++;
                break;

            case 2 :
                scentedPowerbait++;
                break;

            case 3 :
                tackleVariants();
        }
        powerBait();
    }

    /**
     * manipulates the data fields (earthworm and mealWorm) by increment according to the users desire.
     * @throws FileNotFoundException needed to complete the compiling of the program.
     */
    public void liveBait() throws FileNotFoundException{
        Scanner input = new Scanner(System.in);

        System.out.println("Live bait is a great way to attract fish. However, that also means you will be" +
                "\nfrequently attracting smaller fish too. If you get some you will want to wait until the day" +
                "\nof or before to purchase your baits. *note: keep your live baits in a cool place if possible.");

        System.out.println("1) Earthworms - $5.00\n2) Meal-worms - $5.00\n3) Go Back");
        int select = input.nextInt();

        switch (select){
            case 1 :
                earthworm++;
                break;

            case 2 :
                mealWorm++;
                break;

            case 3 :
                tackleVariants();
        }
        liveBait();
    }

    /**
     * manipulates the data fields (sSwimBait and lSwimBait) by increment according to the users desire.
     * @throws FileNotFoundException needed to complete the compiling of the program.
     */
    public void swimBait() throws FileNotFoundException {
        Scanner input = new Scanner(System.in);

        System.out.println("Swim baits work by mimicking small, tasty fish, all alone for a large, usually bass," +
                "\nto attack aggressively. It tends to work best by reeling as slowly as possible.");

        System.out.println("1) Small Swim bait (set 6 piece) - $7.00\n2) Large Swim bait (individual) -" +
                " $10.00+\n3) Go back");
        int select = input.nextInt();
        switch (select){
            case 1 :
                sSwimBait++;
                break;

            case 2 :
                lSwimBait++;
                break;

            case 3 :
                tackleVariants();
        }
        swimBait();
    }

    /**
     * manipulates the data fields (shallowCrankBait and DeepCrankBait) by increment according to the users desire.
     * @throws FileNotFoundException needed to complete the compiling of the program.
     */
    public void crankBait() throws FileNotFoundException {
        Scanner input = new Scanner(System.in);

        System.out.println("Crank baits come in many shapes, sizes, and colors. They work very well when fishing" +
                "\nfor bass. They are used by reeling in semi-quickly while pointed your rod downwards for" +
                "\nmaximum effect. Crank baits mimic small scared fish, so it is best to match the colors of" +
                "\nyour crank bait to local fish. Blue gill like patterns and colors often make great choices." +
                "\nFor most places in southern Utah, a shallow crank bait is sufficient.");

        System.out.println("1) Shallow Crank Bait - $5.00+\n2) Deep Crank Bait - $10.00+\n3) Go Back");
        int select = input.nextInt();
        switch (select){
            case 1 :
                shallowCrankBait++;
                break;

            case 2 :
                deepCrankBait++;
                break;

            case 3 :
                tackleVariants();
        }
        crankBait();
    }

    /**
     * @param wishlist A .txt File class object. It is needed to complete the printing of the wishlist into the program.
     * @throws FileNotFoundException needed to complete the compiling of the program. Is used by the PrintWriter Class.
     */
    public void printWishlist(File wishlist) throws FileNotFoundException {
        System.out.println("Your wishlist is being generated.");

        PrintWriter output = new PrintWriter(wishlist);
        output.println("Your Wishlist");

        if (pantherMartin > 0){
            output.print("\n" + pantherMartin);
            if (pantherMartin > 1){
                output.print(" Panther Martins: $5.00 each (suggested colors/patterns: black and gold with yellow" +
                        "\ndots or yellow and silver with red dots) Size 4 or 6 recommended.\n");
            }
            else {
                output.print(" Panther Martin: $5.00 each (suggested colors/patterns: black and gold with yellow" +
                        "\ndots or yellow and silver with red dots) Size 4 or 6 recommended.\n");
            }
        }

        if (jakes > 0){
            output.print("\n" + jakes);
            output.print(" Jakes Spin-A-Lure: $4.00 each (suggested colors/patterns: gold with red dots or silver" +
                    "\nwith red dots) 1/4oz recommended.\n");
        }

        if (kastmaster > 0){
            output.print("\n" + kastmaster);
            if (kastmaster > 1) {
                output.print(" Kastmasters: $5.00 each (suggested colors/patterns: silver and blue, gold, or silver)" +
                        "\n1/4oz recommended.\n");
            }
            else {
                output.print(" Kastmaster: $5.00 (suggested colors/patterns: silver and blue, gold, or silver)" +
                        "\n1/4oz recommended.\n");
            }
        }

        if (superDuper > 0){
            output.print("\n" + superDuper);
            if (superDuper > 1){
                output.print(" Super Dupers: $5.00 each (suggested colors: gold or silver) 1/16oz recommended.\n");
            }
            else {
                output.print(" Super Dupers: $5.00 each (suggested colors: gold or silver) 1/16oz recommended.\n");
            }
        }

        if (sGrubSet > 0){
            output.print("\n" + sGrubSet);
            if (sGrubSet > 1){
                output.print(" Small Jig sets: $8.00 - $28.00 (suggested colors chartreuse or darker colors for the" +
                        "\nhead, and white for the base) *note: expensive does not necessarily mean better." +
                        "\nUsually expensive products are more durable and may have a slight edge with a change" +
                        "\nin smell.\n");
            }
            else {
                output.print(" Small Jig set: $8.00 - $28.00 (suggested colors chartreuse or darker colors for" +
                        "\nthe head, and white for the base) *note: expensive does not necessarily mean better." +
                        "\nUsually expensive products are more durable and may have a slight edge with a change" +
                        "\nin smell.\n");
            }
        }

        if (lGrubSet > 0){
            output.print("\n" + lGrubSet);
            if (lGrubSet > 1){
                output.print(" Large Jig sets: $8.00 - $28.00 (suggested colors: chartreuse or darker colors for the" +
                        "\nhead, and white for the body) *note: expensive does not necessarily mean better." +
                        "\nUsually expensive products are more durable and may have a slight edge with a change" +
                        "\nin smell.\n");
            }
            else {
                output.print(" Large Jig sets: $8.00 - $28.00 each (suggested colors: chartreuse or darker colors for" +
                        "\nthe head, and white for the body) *note: expensive does not necessarily mean better." +
                        "\nUsually expensive products are more durable and may have a slight edge with a change" +
                        "\nin smell.\n");
            }
        }

        if (nedStick > 0){
            output.print("\n" + nedStick);
            if (nedStick > 1){
                output.print(" Ned Stick Set: $9.00 (suggested colors: chartreuse or darker colors for the shroom" +
                        "\nhead, and with white on the body) it is recommended that you watch a video to know how" +
                        "\nto rig it before you leave on your fishing trip.\n");
            }
            else {
                output.print(" Ned Stick Set: $9.00 each (suggested colors: chartreuse or darker colors for the" +
                        "\nshroom head, and with white on the body) it is recommended that you watch a video to" +
                        "\nknow how to rig it before you leave on your fishing trip.\n");
            }
        }

        if (finesseStick > 0) {
            output.print("\n" + finesseStick);
            if (finesseStick > 1) {
                output.print(" Finesse Stick set: $6.00 (suggested colors: chartreuse or darker colors for the" +
                        "\nshroom head, and with white on the body) it is recommended that you watch a video to" +
                        "\nknow how to rig it before you leave on your fishing trip.\n");
            }
            else {
                output.print(" Finesse Stick set: $6.00 each (suggested colors: chartreuse or darker colors for the" +
                        "\nshroom head and with white on the body) it is recommended that you watch a video to know" +
                        "\nhow to rig it before you leave on your fishing trip.\n");
            }
        }

        if (colorPowerbait > 0) {
            output.print("\n" + colorPowerbait);
            if (colorPowerbait > 1) {
                output.print(" bottles of Powerbait: $5.00 each (Suggested colors: rainbow, yellow, and green) You" +
                        "\nprobably won't need to buy more than 2. As powerbait will eventually dry out.\n");
            }
            else {
                output.print(" bottles of Powerbait: $5.00 (Suggested colors: rainbow, yellow, and green) You" +
                        "\nprobably won't need to buy more than 2. As powerbait will eventually dry out.\n");
            }
        }

        if (scentedPowerbait > 0) {
            output.print("\n" + scentedPowerbait);
            if (scentedPowerbait > 1) {
                output.print(" bottles of Powerbait: $5.00 each (suggested scents: cheese, corn, or garlic) You" +
                        "\nprobably won't need to buy more than 2. As powerbait will eventually dry out.\n");
            }
            else {
                output.print(" bottle of Powerbait: $5.00 (suggested scents: cheese, corn, or garlic) You probably" +
                        "\nwon't need to buy more than 2. As powerbait will eventually dry out.\n");
            }
        }

        if (earthworm > 0) {
            output.print("\n" + earthworm);
            if (earthworm > 1) {
                output.print(" pack of Earthworms: $5.00 for 20 worms. You can make your worms last longer by" +
                        "\ntearing/cutting them into smaller pieces. *note: They are alive and they squirm. If" +
                        "\nyou don't want to handle one don't purchase them.\n");
            }
            else {
                output.print(" packs of Earthworms: $5.00 for 20 worms. You can make your worms last longer by" +
                        "\ntearing/cutting them into smaller pieces. *note: They are alive and they squirm. If" +
                        "\nyou don't want to handle one, don't purchase them.\n");
            }
        }

        if (mealWorm > 0) {
            output.print("\n" + mealWorm);
            if (mealWorm > 1) {
                output.print(" pack of Meal-worms: $3.00 for 1.2oz. One to two packs of meal-worms will suffice" +
                        "\nfor your trip. *note: They are alive and they squirm. If you don't want to handle one," +
                        "\ndon't purchase them.\n");
            }
            else {
                output.print(" packs of Meal-worms: $3.00 for 1.2oz. One to two packs of meal-worms will suffice" +
                        "\nfor your trip. *note: They are alive and they squirm. If you don't want to handle one," +
                        "\ndon't purchase them.\n");
            }
        }

        if (sSwimBait > 0) {
            output.print("\n" + sSwimBait);
            if (sSwimBait > 1) {
                output.print(" pack of swim baits: $7.00 pack of 6 each (suggested colors/patterns: it is best" +
                        "\nto match the colors and patterns to match the minnows and other small fish.)\n");
            }
            else {
                output.print(" pack of swim baits: $7.00 pack of 6 (suggested colors/patterns: it is best to" +
                        "\nmatch the colors and patterns to match the minnows and other small fish.)\n");
            }
        }

        if (lSwimBait > 0) {
            output.print("\n" + lSwimBait);
            if (lSwimBait > 1) {
                output.print(" Swim bait: $10.00+ each (Suggested characteristics: it is best to match the" +
                        "\ncolors and patterns to small fish such as blue gill or small mouth bass.) For any" +
                        "\nfishing trip you likely won't need more than 2.\n");
            }
            else {
                output.print(" Swim bait: $10.00+ (Suggested characteristics: it is best to match the colors" +
                        "\nand patterns to small fish such as blue gill or small mouth bass.) For any fishing" +
                        "\ntrip you likely won't need more than 2.\n");
            }
        }

        if (shallowCrankBait > 0) {
            output.print("\n" + shallowCrankBait);
            if (shallowCrankBait > 1) {
                output.print(" Shallow Crank bait: $5.00+ each (Suggested characteristics: it is best to match" +
                        "\nthe colors and patterns to small fish such as blue gill or small mouth bass.) For any" +
                        "\nfishing trip you likely won't need more than 2.\n");
            }
            else {
                output.print(" Shallow Crank bait: $5.00+ (Suggested characteristics: it is best to match the" +
                        "\ncolors and patterns to small fish such as blue gill or small mouth bass.) For any" +
                        "\nfishing trip you likely won't need more than 2.\n");
            }
        }

        if (deepCrankBait > 0) {
            output.print("\n" + deepCrankBait);
            if (deepCrankBait > 1) {
                output.print(" Deep Crank bait: $10.00+ (Suggested characteristics: it is best to match the" +
                        "\ncolors and patterns to small fish such as blue gill or small mouth bass.) For any" +
                        "\nfishing trip you likely won't need more than 2.\n");
            }
            else {
                output.print(" Deep Crank bait: $10.00+ (Suggested characteristics: it is best to match the" +
                        "\ncolors and patterns to small fish such as blue gill or small mouth bass.) For any" +
                        "\nfishing trip you likely won't need more than 2.\n");
            }
        }

        output.println("\nIt is recommended that if you don't know how to rig (or \"tie\") the lure/bait to look up" +
                "\na video. These lures and baits are beginner-friendly and are some of the best choices for fishing" +
                "\nin southern Utah. Happy Fishing!");
        output.close();
        System.exit(1);
    }
}